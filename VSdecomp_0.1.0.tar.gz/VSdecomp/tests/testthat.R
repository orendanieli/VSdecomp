library(testthat)
library(VSdecomp)

test_check("VSdecomp")
